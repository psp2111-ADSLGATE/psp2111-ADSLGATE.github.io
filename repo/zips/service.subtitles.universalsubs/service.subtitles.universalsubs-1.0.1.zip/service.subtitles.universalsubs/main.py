# -*- coding: utf-8 -*-

import sys

from resources.lib.subtitleaddon import SubtitleAddon

if __name__ == "__main__":
    addon = SubtitleAddon()
    addon.main(sys.argv)
