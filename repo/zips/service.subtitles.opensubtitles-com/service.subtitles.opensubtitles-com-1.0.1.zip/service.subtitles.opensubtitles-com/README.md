OpenSubtitles.com KODI add-on
=============================
Search and download subtitles for movies and TV-Series from OpenSubtitles.com. Search in 75 languages, 4.000.000+ subtitles, daily updates.

REST API implementation based on tomburke25 [python-opensubtitles-rest-api](https://github.com/tomburke25/python-opensubtitles-rest-api)                            

1.0.0
 Initial version, forked from https://github.com/juokelis/service.subtitles.opensubtitles
 Search fixed and improved