service.subtitles.subscene
==========================

Subscene.com subtitle service plugin for Kodi (formerly XBMC)

Compatible with Kodi 18 (Krypton) and 19 (Matrix)

Maintainer history:\
2019-currently: maintained by wuff - AnonTester\
2019: forked and fixed by Jarmo\
2014-16: originally written by CrowleyAJ - manacker

Forum thread: http://forum.xbmc.org/showthread.php?tid=184854
